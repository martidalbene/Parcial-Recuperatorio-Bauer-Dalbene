public interface IItem
{
    void OnItemGrab();
}
