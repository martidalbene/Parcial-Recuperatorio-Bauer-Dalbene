public interface IDamageable
{
    void GetDamage(float amount, float stunChance);
    void GetStun(float time);
    void GetDeath();

    void UpdateStunTime(float delta);
}
