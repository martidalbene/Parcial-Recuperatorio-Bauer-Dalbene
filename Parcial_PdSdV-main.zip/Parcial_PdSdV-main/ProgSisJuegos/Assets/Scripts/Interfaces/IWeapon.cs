using UnityEngine;

public interface IWeapon
{
    public WeaponType Type { get; }
    public WeaponHandle Handle { get; }
    public AudioClip DeploySound { get; }
    public float DeploySoundVolume { get; }
    public AudioClip HolsterClip { get; }
    public float HolsterSoundVolume { get; }
    public bool Ready { get; }

    void OnDrawWeapon();
    void OnHolsterWeapon();
    void PlayAudio(AudioClip clip, float volume);
    void Recoil(float delta);
    void Shoot(Vector3 bulletOut, Vector3 forward);
}
