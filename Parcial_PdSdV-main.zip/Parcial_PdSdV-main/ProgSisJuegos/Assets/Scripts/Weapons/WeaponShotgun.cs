using UnityEngine;

public class WeaponShotgun : BaseWeapon
{
    [SerializeField, Range(0.1f, 0.2f)] private float _pelletVariationAmount = 0.15f;
    public override void Shoot(Vector3 outPos, Vector3 forward)
    {
        if (!Ready) return;

        Vector3 randVector = new Vector3(Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount));
        base.Shoot(outPos, forward + randVector);

        randVector = new Vector3(Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount));
        base.ShootBulletCast(outPos, forward + randVector);

        randVector = new Vector3(Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount));
        base.ShootBulletCast(outPos, forward + randVector);

        randVector = new Vector3(Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount), Random.Range(-_pelletVariationAmount, _pelletVariationAmount));
        base.ShootBulletCast(outPos, forward + randVector);
    }
}
