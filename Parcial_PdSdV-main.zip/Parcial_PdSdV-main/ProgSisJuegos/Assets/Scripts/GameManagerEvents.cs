using System;
using UnityEngine;

public static class GameManagerEvents
{
    // Events
    public static Action<ICommand> EnqueueCommand;
    public static Action<Transform, KeyDirection, float> OnCameraChange;
    public static Action<AudioClip, Vector3, float> PlaySoundAtLocation;

    // Commands
    public static Action<ZombieType, Vector3, Quaternion> CommandSpawnZombie;
    public static Action<SpiderType, Vector3, Quaternion> CommandSpawnSpider;
    public static Action<TyrantType, Vector3, Quaternion> CommandSpawnTyrant;
}
