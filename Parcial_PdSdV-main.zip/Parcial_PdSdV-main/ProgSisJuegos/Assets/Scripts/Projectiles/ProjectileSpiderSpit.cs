using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileSpiderSpit : BaseProjectile
{
    protected private void OnTriggerEnter(Collider other)
    {
        if ((!other.CompareTag("Player") && !other.CompareTag("Untagged")) || other.isTrigger) return;

        other.transform.TryGetComponent(out IDamageable damageable);
        damageable?.GetDamage(damage, StunChance);

        GameManagerEvents.PlaySoundAtLocation(SoundsManager.SoundsDatabase.SoundSpiderSpitHit, transform.position, 1.5f);
        Destroy(this.gameObject);
    }
}
