using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileSpiderSpitPoison : ProjectileSpiderSpit
{
    new protected private void OnTriggerEnter(Collider other)
    {
        if ((!other.CompareTag("Player") && !other.CompareTag("Untagged")) || other.isTrigger) return;

        other.transform.TryGetComponent(out IDamageable damageable);
        if (damageable != null && other.CompareTag("Player")) PoisonEffect();
        damageable?.GetDamage(damage, StunChance);

        GameManagerEvents.PlaySoundAtLocation(SoundsManager.SoundsDatabase.SoundSpiderSpitHit, transform.position, 2);
        Destroy(this.gameObject);
    }

    protected virtual private void PoisonEffect()
    {
        PlayerEvents.OnGetPoisoned?.Invoke(true);
    }
}
