using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SpiderType
{
    None, Spider01, Spider02, Spider03, Spider04, Spider05
}

[CreateAssetMenu(fileName = "NewSpiderCharacterData", menuName = "Scriptables/Characters/Spider")]
public class DatabaseCharacterSpider : DatabaseCharacter
{
    [SerializeField] private BaseProjectile _spiteProjectile;

    [Header("Spider settings")]
    [SerializeField] private SpiderType _spiderType = SpiderType.Spider01;
    [SerializeField, Range(15, 25)] private float _aggroRange = 22;
    [SerializeField, Range(0.1f, 2)] private float _facingEnemyMinTolerance = 0.4f;
    [SerializeField, Range(10, 20)] private float _attackRange = 15;
    [SerializeField] private float _attackOutTime = 1;

    [Header("Sound settings")]
    [SerializeField] private List<AudioClip> _errandClips;
    [SerializeField] private List<AudioClip> _attackClips;
    [SerializeField, Range(-.5f, .5f)] private float _minPitchModifier;
    [SerializeField, Range(-.5f, .5f)] private float _maxPitchModifier;

    public BaseProjectile SpiderSpiteProjectile => _spiteProjectile;
    public SpiderType SpiderType => _spiderType;

    public float SpiderAggroRange => _aggroRange;
    public float SpiderFacingTolerance => _facingEnemyMinTolerance;
    public float SpiderAttackRange => _attackRange;
    public float SpiderAttackOutTime => _attackOutTime;

    public AudioClip SoundSpiderErrands => _errandClips[Random.Range(0, _errandClips.Count)];
    public AudioClip SoundSpiderAttack => _attackClips[Random.Range(0, _attackClips.Count)];
    public float SoundSpiderMinPitch => _minPitchModifier;
    public float SoundSpiderMaxPitch => _maxPitchModifier;
}
