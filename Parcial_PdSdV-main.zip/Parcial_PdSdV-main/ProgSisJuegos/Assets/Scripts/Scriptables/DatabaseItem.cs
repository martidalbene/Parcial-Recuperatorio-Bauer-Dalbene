using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ItemType
{
    None, Weapon, Antidote, HealthSpray
}

[CreateAssetMenu(fileName = "NewItemData", menuName = "Scriptables/Items/Item")]
public class DatabaseItem : ScriptableObject
{
    [SerializeField] private BaseItem _prefab;

    [SerializeField] private ItemType _type;
    [SerializeField] private AudioClip _pickedUpSound;
    [SerializeField] private float _pickedUpVolume;

    public BaseItem ItemPrefab => _prefab;

    public ItemType Type => _type;
    public AudioClip PickedUpSound => _pickedUpSound;
    public float PickedUpVolume => _pickedUpVolume;
}
