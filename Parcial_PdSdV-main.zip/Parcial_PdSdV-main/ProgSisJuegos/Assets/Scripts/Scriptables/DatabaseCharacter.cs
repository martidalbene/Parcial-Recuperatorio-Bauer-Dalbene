using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public enum FootstepType
{
    Gravel, Grass, Metal, Fancy
}
[CreateAssetMenu(fileName = "NewCharacterData", menuName = "Scriptables/Characters/Character")]
public class DatabaseCharacter : ScriptableObject
{
    [SerializeField] private BaseCharacter _prefab;

    [Header("Character settings")]
    [SerializeField, Range(0.01f, 15)] private float _speed = 0.5f;
    [SerializeField, Range(0.01f, 15)] private float _runSpeed = 0.5f;
    [SerializeField, Range(0.01f, 15)] private float _turnSpeed = 10;
    [SerializeField] private float _life = 100;
    [SerializeField, Range(0, 2)] private float _stunTime = 1;
    [SerializeField, Range(0, 100)] private float _stunChance = 30;

    [Header("Sound settings")]
    [SerializeField] private List<AudioClip> _damagedClips;
    [SerializeField] private List<AudioClip> _deathClips;

    public BaseCharacter CharacterPrefab => _prefab;

    public float CharacterSpeed => _speed;
    public float CharacterRunSpeed => _runSpeed;
    public float CharacterTurnSpeed => _turnSpeed;
    public float CharacterLife => _life;
    public float CharacterStunTime => _stunTime;
    public float CharacterStunChance => _stunChance;


    public AudioClip SoundDamaged => _damagedClips[Random.Range(0, _damagedClips.Count)];
    public AudioClip SoundDeath => _deathClips[Random.Range(0, _deathClips.Count)];
}
