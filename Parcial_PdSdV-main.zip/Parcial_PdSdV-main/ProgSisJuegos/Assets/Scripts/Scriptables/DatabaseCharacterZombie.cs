using System.Collections.Generic;
using UnityEngine;

public enum ZombieType
{
    None, Zombie01, Zombie02, Zombie03, Zombie04, Zombie05, Zombie06
}

[CreateAssetMenu(fileName = "NewZombieCharacterData", menuName = "Scriptables/Characters/Zombie")]
public class DatabaseCharacterZombie : DatabaseCharacter
{
    [Header("Zombie settings")]
    [SerializeField] private ZombieType _zombieType = ZombieType.Zombie01;
    [SerializeField] private float _aggroRange = 10;
    [SerializeField, Range(0.1f, 2)] private float _facingEnemyMinTolerance = 0.25f;
    [SerializeField, Range(0.1f, 3)] private float _attackRange = 0.75f;
    [SerializeField] private List<float> _attackDamage = new List<float>();
    [SerializeField, Range(0, 100)] private List<float> _attackStunChance = new List<float>();
    [SerializeField] private List<float> _attackOutTime = new List<float>();

    [Header("Sound settings")]
    [SerializeField, Range(-.5f, .5f)] private float _minPitchModifier;
    [SerializeField, Range(-.5f, .5f)] private float _maxPitchModifier;
    [SerializeField] private List<AudioClip> _zombieErrandClips;

    public ZombieType ZedType => _zombieType;

    public float ZedFacingEnemyMinTolerance => _facingEnemyMinTolerance;
    public float ZedAggroRange => _aggroRange;
    public float ZedAttackRange => _attackRange;

    public List<float> ZedAttackDamage => _attackDamage;
    public List<float> ZedAttackStunChance => _attackStunChance;
    public List<float> ZedAttackOutTime => _attackOutTime;

    public float SoundZombieMinPitch => _minPitchModifier;
    public float SoundZombieMaxPitch => _maxPitchModifier;
    public AudioClip SoundZombieErrands => _zombieErrandClips[Random.Range(0, _zombieErrandClips.Count)];
}
