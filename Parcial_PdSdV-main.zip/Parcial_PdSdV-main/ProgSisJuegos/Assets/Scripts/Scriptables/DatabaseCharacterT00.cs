using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TyrantType
{
    TyrantT00
}

[CreateAssetMenu(fileName = "NewTyrantCharacterData", menuName = "Scriptables/Characters/T00")]
public class DatabaseCharacterT00 : DatabaseCharacter
{
    [SerializeField] private BaseProjectile _rockProjectile;
    [SerializeField] private TyrantType _type;  

    [Header("T00 settings")]
    [SerializeField] private float _aggroRange = 20;
    [SerializeField, Range(0.1f, 2)] private float _facingEnemyMinTolerance = 0.25f;
    [SerializeField, Range(0.1f, 3)] private float _meleeAttackRange = 0.75f;
    [SerializeField, Range(0.1f, 20)] private float _rockAttackRange = 0.75f;
    [SerializeField] private float _attackDamage = 30;
    [SerializeField] private float _attackOutTime = 1;
    [SerializeField] private float _attackStunChance = 1;
    [SerializeField, Range(1, 5)] private float _rockMinTimeChance = 1;
    [SerializeField, Range(8, 20)] private float _rockMaxTimeChance = 20;
    [SerializeField] private float _rockOutTime = 1;

    [Header("Sound settings")]
    [SerializeField, Range(-.5f, .5f)] private float _minPitchModifier;
    [SerializeField, Range(-.5f, .5f)] private float _maxPitchModifier;
    [SerializeField] private List<AudioClip> _errandClips;
    [SerializeField] private List<AudioClip> _meleeAttackClips;
    [SerializeField] private List<AudioClip> _rockThrowClips;

    public BaseProjectile TyrantProjectile => _rockProjectile;
    public TyrantType TyrantType => _type;

    public float TyrantFacingTolerance => _facingEnemyMinTolerance;
    public float TyrantAggroRange => _aggroRange;

    public float TyrantMeleeAttackRange => _meleeAttackRange;
    public float TyrantRockAttackRange => _rockAttackRange;

    public float TyrantMeleeDamange => _attackDamage;
    public float TyrantMeleeOutTime => _attackOutTime;
    public float TyrantMeleeStunChance => _attackStunChance;

    public float TyrantRockAttackMinTimeChance => _rockMinTimeChance;
    public float TyrantRockAttackMaxTimeChance => _rockMaxTimeChance;
    public float TyrantRockOutTime => _rockOutTime;

    public float SoundTyrantMinPitch => _minPitchModifier;
    public float SoundTyrantMaxPitch => _maxPitchModifier;

    public AudioClip SoundTyrantMeleeAttack => _meleeAttackClips[Random.Range(0, _meleeAttackClips.Count)];
    public AudioClip SoundTyrantRockThrow => _rockThrowClips[Random.Range(0, _rockThrowClips.Count)];
    public AudioClip SoundTyrantErrands => _errandClips[Random.Range(0, _errandClips.Count)];
}
