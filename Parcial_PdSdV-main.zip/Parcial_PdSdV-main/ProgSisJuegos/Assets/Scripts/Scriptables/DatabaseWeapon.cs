using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum WeaponType
{
    None, Pistol, Rifle, Shotgun
}

public enum WeaponHandle
{
    OneHand, TwoHands
}

[CreateAssetMenu(fileName = "NewWeaponData", menuName = "Scriptables/Weapons")]
public class DatabaseWeapon : ScriptableObject
{
    [SerializeField] private BaseWeapon _prefab;

    [Header("Weapon settings")]
    [SerializeField] private WeaponType _type;
    [SerializeField] private WeaponHandle _handler;
    [SerializeField] private Sprite _icon;
    [SerializeField] private float _damage;
    [SerializeField] private float _stunChance;
    [SerializeField] private float _recoil;
    [SerializeField] private ParticleSystem _muzzleParticle;
    [SerializeField] private ParticleSystem _hitWallPrefab;
    [SerializeField] private ParticleSystem _hitBodyPrefab;

    [Header("Sounds")]
    [SerializeField] private AudioClip _shootClip;
    [SerializeField, Range(0.1f, 2)] private float _shootVolume = 1;
    [SerializeField] private AudioClip _deployClip;
    [SerializeField, Range(0.1f, 2)] private float _deployVolume = 1;
    [SerializeField] private AudioClip _holsterClip;
    [SerializeField, Range(0.1f, 2)] private float _holsterVolume = 1;

    public BaseWeapon WeaponPrefab => _prefab;

    public WeaponType Type => _type;
    public WeaponHandle Handler => _handler;
    public Sprite Icon => _icon;
    public float Damage => _damage;
    public float StunChance => _stunChance;
    public float Recoil => _recoil;
    public ParticleSystem MuzzlePartice => _muzzleParticle;
    public ParticleSystem HitWallPartice => _hitWallPrefab;
    public ParticleSystem HitBodyPartice => _hitBodyPrefab;

    public AudioClip ShootAudioClip => _shootClip;
    public float ShootAudioClipVolume => _shootVolume;
    public AudioClip DeployAudioClip => _deployClip;
    public float DeployAudioClipVolume => _deployVolume;
    public AudioClip HolsterAudioClip => _holsterClip;
    public float HolsterAudioClipVolume => _holsterVolume;
}
