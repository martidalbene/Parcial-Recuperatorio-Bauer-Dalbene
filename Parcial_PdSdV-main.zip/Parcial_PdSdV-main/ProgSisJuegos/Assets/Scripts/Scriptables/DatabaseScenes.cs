using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewScenesData", menuName = "Scriptables/Scenes")]
public class DatabaseScenes : ScriptableObject
{
    [SerializeField] private string _mainMenuScene;
    [SerializeField] private string _gameScene;
    [SerializeField] private string _testScene;

    public string MainMenu => _mainMenuScene;
    public string GameScene => _gameScene;
    public string TestScene => _testScene;
}
