using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewWeaponItemData", menuName = "Scriptables/Items/Weapon")]
public class DatabaseItemWeapon : DatabaseItem
{
    [SerializeField] private WeaponType _weaponType;

    public WeaponType WeaponType => _weaponType;
}
