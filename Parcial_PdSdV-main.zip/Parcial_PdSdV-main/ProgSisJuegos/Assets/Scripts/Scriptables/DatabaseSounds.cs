using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TerrainType
{
    Gravel, Metal, Grass, Fancy
}
[CreateAssetMenu(fileName = "NewSoundsData", menuName = "Scriptables/Sounds")]
public class DatabaseSounds : ScriptableObject
{
    [SerializeField] private GameObject _oneShotAudioPrefab;

    [Header("IU Sounds")]
    [SerializeField] private AudioClip _itemPickupSound;
    [SerializeField] private AudioClip _itemSwapSound;

    [Header("Generic swing sounds")]
    [SerializeField] private List<AudioClip> _swingSounds;

    [Header("General sounds")]
    [SerializeField] private List<AudioClip> _bulletHitSounds;
    [SerializeField] private List<AudioClip> _bulletRicochetSounds;
    [SerializeField] private List<AudioClip> _bodyFallSounds;
    [SerializeField] private List<AudioClip> _debrisHitSounds;

    [Header("Footsteps sounds")]
    [SerializeField] private List<AudioClip> _footstepGravel;
    [SerializeField] private List<AudioClip> _footstepMetal;
    [SerializeField] private List<AudioClip> _footstepGrass;
    [SerializeField] private List<AudioClip> _footstepFancy;

    [Header("Spider sounds")]
    [SerializeField] private List<AudioClip> _spiderFootstep;
    [SerializeField] private List<AudioClip> _spiderSpitHit;

    public GameObject SoundOneShotLocationPrefab => _oneShotAudioPrefab;

    public AudioClip SoundUIItemPickup => _itemPickupSound;
    public AudioClip SoundUIItemSwap => _itemSwapSound;

    public AudioClip SoundSwing => _swingSounds[Random.Range(0, _swingSounds.Count)];

    public AudioClip SoundBulletHit => _bulletHitSounds[Random.Range(0, _bulletHitSounds.Count)];
    public AudioClip SoundBulletRicochet => _bulletRicochetSounds[Random.Range(0, _bulletRicochetSounds.Count)];
    public AudioClip SoundBodyFall => _bodyFallSounds[Random.Range(0, _bodyFallSounds.Count)];
    public AudioClip SoundDebrisHit => _debrisHitSounds[Random.Range(0, _debrisHitSounds.Count)];

    public AudioClip SoundFootStepGravel => _footstepGravel[Random.Range(0, _footstepGravel.Count)];
    public AudioClip SoundFootStepGrass => _footstepGrass[Random.Range(0, _footstepGrass.Count)];
    public AudioClip SoundFootStepMetal => _footstepMetal[Random.Range(0, _footstepMetal.Count)];
    public AudioClip SoundFootStepFancy => _footstepFancy[Random.Range(0, _footstepFancy.Count)];

    public AudioClip SoundSpiderFootStep => _spiderFootstep[Random.Range(0, _spiderFootstep.Count)];
    public AudioClip SoundSpiderSpitHit => _spiderSpitHit[Random.Range(0, _spiderSpitHit.Count)];

    public AudioClip SoundFootstep(TerrainType type)
    {
        switch (type)
        {
            case TerrainType.Gravel: return SoundFootStepGravel;
            case TerrainType.Metal: return SoundFootStepMetal;
            case TerrainType.Grass: return SoundFootStepGrass;
            case TerrainType.Fancy: return SoundFootStepFancy;
            default: return SoundFootStepGravel;
        }
    }
}
