using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerEvents : MonoBehaviour
{
    // Values
    private static bool _playerDead = false;
    private static Transform _playerLocation;

    // Public values
    public static Transform PlayerLocation => _playerLocation;
    public static bool PlayerDead => _playerDead;

    // Events
    public static Action<ItemType, WeaponType> OnItemGrab;
    public static Action<float, bool> OnHealthChange;
    public static Action<bool> OnGetPoisoned;
    public static Action OnPlayerDeath;
    public static Action OnPlayerEndLevel;
    public static Action<KeyDirection> OnPlayerSwitchControlScheme;

    public static void UpdatePlayerLocation(Transform value)
    {
        _playerLocation = value;
    }

    public static void UpdatePlayerDeath(bool isDead)
    {
        _playerDead = isDead;
    }
}
