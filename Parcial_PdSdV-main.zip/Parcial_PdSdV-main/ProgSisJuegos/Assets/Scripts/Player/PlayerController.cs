using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

public enum PlayerAim {
    None, Pistol, TwoHands
}

// Direction for each key: W S A D, Forward, Backward, Left, Right
public enum KeyDirection
{
    FBLR, BFLR, FBRL, BFRL, LRFB, RLFB, LRBF
}

public class PlayerController : BaseCharacter
{
    // Settings
    [SerializeField] private float _aimSphereRange = 8;
    [SerializeField, Range(1, 2)] private float _aimFixedHeight = 1.6f;
    [SerializeField, Range(0.1f, 2)] private float _aimingTurnRate = 0.5f;

    // References
    [SerializeField] private List<BaseWeapon> _availableWeapons = new List<BaseWeapon>();
    [SerializeField] private List<BaseWeapon> _unavailableWeapons = new List<BaseWeapon>();

    // Values
    private int _weaponIndex;
    private IWeapon _currentWeapon;
    private PlayerAim _aimingStatus;
    private KeyDirection _movementScheme = KeyDirection.FBLR;
    private KeyDirection _wantedMovementScheme = KeyDirection.FBLR;
    private Vector3 _movement;
    private Vector3 _savedMovement;
    private GameObject _currentEnemy;
    private bool _hasPoisonDamage;
    private int _layer_mask;
    private bool _godMode = false;

    public Vector3 PlayerPosition => transform.position;
    public Vector3 PlayerFixedAimHeight => new Vector3(0, _aimFixedHeight, 0);
    public bool IsPoisoned => _hasPoisonDamage;

    private void OnDestroy()
    {
        UnsubscribeAll();
    }

    protected private override void Update()
    {
        if (IsDead) 
        {
            this.enabled = false;
            return;
        }

        if (Input.GetKeyDown(KeyCode.Tab))
        {
            _godMode = !_godMode;
            Debug.Log($"GodMode: {_godMode}");
        }

        float delta = Time.deltaTime;
        UpdateStunTime(delta);
        if (IsStunned) return;

        _currentWeapon?.Recoil(delta);

        // TODO: add configurable keys?
        switch (_movementScheme)
        {
            case KeyDirection.FBLR:
                _movement = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical")).normalized;
                break;

            case KeyDirection.BFLR:
                _movement = new Vector3(Input.GetAxisRaw("Horizontal"), 0, -Input.GetAxisRaw("Vertical")).normalized;
                break;

            case KeyDirection.FBRL:
                _movement = new Vector3(-Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical")).normalized;
                break;

            case KeyDirection.BFRL:
                _movement = new Vector3(-Input.GetAxisRaw("Horizontal"), 0, -Input.GetAxisRaw("Vertical")).normalized;
                break;

            case KeyDirection.LRFB:
                _movement = new Vector3(Input.GetAxisRaw("Vertical"), 0, Input.GetAxisRaw("Horizontal")).normalized;
                break;

            case KeyDirection.RLFB:
                _movement = new Vector3(Input.GetAxisRaw("Vertical"), 0, -Input.GetAxisRaw("Horizontal")).normalized;
                break;

            case KeyDirection.LRBF:
                _movement = new Vector3(-Input.GetAxisRaw("Vertical"), 0, Input.GetAxisRaw("Horizontal")).normalized;
                break;
        }

        // Swap schemes when player changes direction
        if (_savedMovement != _movement)
        {
            _movementScheme = _wantedMovementScheme;
            _savedMovement = _movement;
        }

        Aim(Input.GetKey(KeyCode.LeftShift) && MovementStatus == CharacterMovementStatus.Idle);
        if (Input.GetKeyDown(KeyCode.Space) && _aimingStatus == PlayerAim.None) SwapWeapon();

        // If aiming, movement is bypassed and the player will rotate instead
        if (_aimingStatus != PlayerAim.None)
        {
            float hAxis = Input.GetAxisRaw("Horizontal");
            // Keep rotation
            if (hAxis != 0) RotateCharacter(transform.right * hAxis, delta * _aimingTurnRate);
            return;
        }

        if (_movement == Vector3.zero || !_currentWeapon.Ready)
        {
            UpdateMovement(CharacterMovementStatus.Idle);
            return;
        }

        // Movement & rotation
        if (Input.GetKey(KeyCode.LeftShift)) Run();
        else UpdateMovement(CharacterMovementStatus.Walking);

        RotateCharacter(_movement, delta);
    }

    protected private void FixedUpdate()
    {
        CharacterGravitry();

        if (IsDead || IsStunned || _aimingStatus != PlayerAim.None || !_currentWeapon.Ready) return;
        MoveCharacter(_movement);
        PlayerEvents.UpdatePlayerLocation(transform);
    }

    private void UnsubscribeAll()
    {
        foreach (BaseWeapon weapon in _availableWeapons)
            weapon.OnShoot -= Shoot;

        _currentWeapon = null;
        PlayerEvents.OnItemGrab -= ItemGrab;
        PlayerEvents.OnGetPoisoned -= GetPoisonDamage;
        PlayerEvents.OnPlayerSwitchControlScheme -= ChangeControlScheme;
    }

    public override void AdditionalCharacterSetup()
    {
        _layer_mask = LayerMask.GetMask("Enemy", "Default", "Floor", "Damageable");

        PlayerEvents.OnItemGrab += ItemGrab;
        PlayerEvents.OnGetPoisoned += GetPoisonDamage;
        PlayerEvents.OnPlayerSwitchControlScheme += ChangeControlScheme;

        if (_availableWeapons.Count == 0) return;

        foreach (BaseWeapon weapon in _availableWeapons)
        {
            weapon.gameObject.SetActive(false);
            weapon.OnShoot += Shoot;
        }

        _currentWeapon = _availableWeapons[0];
        _availableWeapons[0].gameObject.SetActive(true);
    }

    protected override void Run()
    {
        if (!IsPoisoned) UpdateMovement(CharacterMovementStatus.Running);
    }

    protected private void SwapWeapon()
    {
        if (!_currentWeapon.Ready || _availableWeapons.Count <= 1 || MovementStatus == CharacterMovementStatus.Running) return;

        // Disable current weapon
        _availableWeapons[_weaponIndex].gameObject.SetActive(false);

        if (_weaponIndex + 1 <= _availableWeapons.Count - 1)
        {
            // Swap current and enable next one
            _weaponIndex += 1;
            _currentWeapon = _availableWeapons[_weaponIndex];
        }
        else
        {
            _weaponIndex = 0;
            _currentWeapon = _availableWeapons[_weaponIndex];
        }

        // Then enable current weapon
        _availableWeapons[_weaponIndex].gameObject.SetActive(true);

        // UI & sounds
        UIEvents.OnInventoryUpdateCurrentWeapon(_currentWeapon.Type);
        UIEvents.PlayUISound(SoundsManager.SoundsDatabase.SoundUIItemSwap, 0.65f);
    }

    protected private void Shoot()
    {
        Anim.SetTrigger("fireWeapon");
    }
    
    protected private void PlayWeaponAudio(AudioClip shootClip, float volume)
    {
        Audio.PlayOneShot(shootClip, volume);
    }

    protected private void Aim(bool isAiming)
    {
        if (isAiming)
        {
            // Triggering aim execs OnDrawWeapon to prevent instant shooting
            if (_currentWeapon?.Handle == WeaponHandle.OneHand)
            {
                if (_aimingStatus != PlayerAim.Pistol)
                    _currentWeapon?.OnDrawWeapon();

                _aimingStatus = PlayerAim.Pistol;
            }
            else if (_aimingStatus != PlayerAim.TwoHands)
            {
                if (_aimingStatus != PlayerAim.TwoHands)
                    _currentWeapon?.OnDrawWeapon();

                _aimingStatus = PlayerAim.TwoHands;
            }

            if (Input.GetKeyDown(KeyCode.Space))
                _currentWeapon?.Shoot(PlayerPosition + PlayerFixedAimHeight, transform.forward);

            if (_currentEnemy == null)
            {
                AimToEnemy();

                if (_currentEnemy != null)
                {
                    Vector3 lookDir = (_currentEnemy.transform.position - PlayerPosition).normalized;
                    transform.rotation = Quaternion.LookRotation(new Vector3(lookDir.x, 0, lookDir.z));
                }
            }
        }

        else
        {
            // Stopping aim execs OnHolsterWeapon to also prevent instant shooting
            if (_aimingStatus != PlayerAim.None)
                _currentWeapon?.OnHolsterWeapon();

            _aimingStatus = PlayerAim.None;

            if (_currentEnemy != null)
                _currentEnemy = null;
        }

        // Set animations
        switch (_aimingStatus)
        {
            case PlayerAim.None:
                Anim.SetBool("aimPistol", false);
                Anim.SetBool("aimTwoHands", false);                
                break;

            case PlayerAim.Pistol:
                UpdateMovement(CharacterMovementStatus.Idle);
                Anim.SetBool("aimPistol", true);
                Anim.SetBool("aimTwoHands", false);                
                break;

            case PlayerAim.TwoHands:
                UpdateMovement(CharacterMovementStatus.Idle);
                Anim.SetBool("aimPistol", false);
                Anim.SetBool("aimTwoHands", true);                
                break;
        }
    }

    protected private void AimToEnemy()
    {
        // Get closer objects
        Collider[] objects = Physics.OverlapSphere(PlayerPosition, _aimSphereRange, _layer_mask);
        if (objects.Length == 0)
        {
            _currentEnemy = gameObject;
            return;
        }

        List<GameObject> enemies = new List<GameObject>();
        float currentDistance = 0;
        GameObject closerEnemy = null;

        // Check for enemies
        foreach (Collider collider in objects)
        {
            if (collider.CompareTag("Enemy"))
            {
                // Check LoS
                if (Physics.Raycast(PlayerPosition + PlayerFixedAimHeight, collider.transform.position - PlayerPosition + PlayerFixedAimHeight, _aimSphereRange, _layer_mask)) continue;

                GameObject enemyObject = collider.gameObject;
                enemies.Add(enemyObject);                
            }
        }

        foreach (GameObject enemy in enemies)
        {
            float distance = Vector3.Distance(enemy.transform.position, PlayerPosition);

            // Set first enemy as starting point
            if (closerEnemy == null)
            {
                closerEnemy = enemy;
                currentDistance = distance;
                continue;
            }

            // Ignore far enemies
            if (distance >= currentDistance) continue;

            // Set new closer enemy
            closerEnemy = enemy;
            currentDistance = distance;
        }

        if (enemies.Count == 0) return;

        if (closerEnemy != null)
            _currentEnemy = closerEnemy;
    }

    protected private void ItemGrab(ItemType type, WeaponType weaponType)
    {
        switch (type)
        {
            case ItemType.Weapon:
                if (weaponType == WeaponType.None) break;

                // Find if the weapon is available to add
                for (int i = 0; i < _unavailableWeapons.Count; i++)
                {
                    if (_unavailableWeapons[i].Type == weaponType)
                    {
                        BaseWeapon weapon = _unavailableWeapons[i];

                        // Subscribe to event then swap item on lists
                        weapon.OnShoot += Shoot;

                        _availableWeapons.Add(_unavailableWeapons[i]);
                        _unavailableWeapons.RemoveAt(i);
                        UIEvents.OnInventoryAddWeapon(weaponType, weapon.Icon);
                        return;
                    }
                }
                break;

            case ItemType.Antidote:
                GetPoisonDamage(false);
                break;
            case ItemType.HealthSpray:
                GetHealth(50);
                break;
        }
    }

    protected private void GetPoisonDamage(bool isPoisoned)
    {
        if (_godMode) return;

        _hasPoisonDamage = isPoisoned;
        PlayerEvents.OnHealthChange(CurrentLife, IsPoisoned);

        // Poison disables running
        if (MovementStatus == CharacterMovementStatus.Running) UpdateMovement(CharacterMovementStatus.Walking);
    }

    public override void GetHealth(float amount)
    {
        base.GetHealth(amount);
        PlayerEvents.OnHealthChange(CurrentLife, IsPoisoned);
    }

    public override void GetDamage(float amount, float stunChance)
    {
        if (_godMode) return;

        if (IsPoisoned) base.GetDamage(amount * 1.25f, stunChance);
        else base.GetDamage(amount, stunChance);

        if (CurrentLife > 0) PlayerEvents.OnHealthChange(CurrentLife, IsPoisoned);
    }
    
    public override void GetDeath()
    {
        PlayerEvents.UpdatePlayerDeath(true);
        PlayerEvents.OnPlayerDeath?.Invoke();
        base.GetDeath();
        UnsubscribeAll();
    }

    protected private void ChangeControlScheme(KeyDirection newScheme)
    {
        print($"Changing control scheme to {newScheme}");
        _wantedMovementScheme = newScheme;
        _savedMovement = _movement;
    }
}
