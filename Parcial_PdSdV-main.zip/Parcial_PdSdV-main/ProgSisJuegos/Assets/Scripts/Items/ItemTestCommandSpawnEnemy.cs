using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ItemTestCommandSpawnEnemy : BaseItem
{
    public DatabaseCharacter prefab;
    public Transform spawnTransform;
    private ICommand _spawnEnemyCommand;

    public bool destroyOnSpawn = false;
    public TextMeshPro text;

    private void Start()
    {
        if (spawnTransform == null || spawnTransform == transform)
        {
            Debug.LogError($"{name}: Transform should not be null or this object.");
            Destroy(gameObject);
        }

        _spawnEnemyCommand = new CommandSpawnEnemy(prefab.CharacterPrefab, spawnTransform);
        text.text = $"SPAWN: {prefab.CharacterPrefab.name}";
    }

    public override void OnItemGrab()
    {
        GameManagerEvents.EnqueueCommand(_spawnEnemyCommand);
        if (destroyOnSpawn) Destroy(gameObject);
    }
}
