using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemTestDamage : BaseItem
{
    [Range(0, 100)] public float damageAmount = 1;
    [Range(0, 100)] public float stunChance = 1;

    public override void OnTriggerEnter(Collider other)
    {
        other.TryGetComponent(out IDamageable damageable);
        damageable?.GetDamage(damageAmount, stunChance);

        OnItemGrab();
    }

    public override void OnItemGrab()
    {
        if (DestroyOnGrab) Destroy(gameObject);
    }
}
