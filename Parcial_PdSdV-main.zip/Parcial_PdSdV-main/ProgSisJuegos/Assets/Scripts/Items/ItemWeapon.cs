using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemWeapon : BaseItem
{
    private DatabaseItemWeapon _weaponData;
    public WeaponType WeapType => _weaponData.WeaponType;

    private void Start()
    {
        _weaponData = (DatabaseItemWeapon)ItemData;
    }

    public override void OnItemGrab()
    {
        UIEvents.PlayUISound?.Invoke(PickedUpSound, PickedUpVolume);
        PlayerEvents.OnItemGrab?.Invoke(Type, WeapType);
        if (DestroyOnGrab) Destroy(gameObject);
    }
}
