using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventQueue : MonoBehaviour
{
    private List<ICommand> commands = new();
    public static EventQueue Instance { get; private set; }
    private static EventQueue _instance;

    public static EventQueue GetInstance()
    {
        return _instance;
    }

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void LateUpdate()
    {
        if (commands.Count == 0) return;

        foreach (var command in commands)
            command.Execute();

        commands.Clear();
    }


    public void EnqueueCommand(ICommand command)
    {
        if (commands.Contains(command)) return;
        commands.Add(command);
    }
}
