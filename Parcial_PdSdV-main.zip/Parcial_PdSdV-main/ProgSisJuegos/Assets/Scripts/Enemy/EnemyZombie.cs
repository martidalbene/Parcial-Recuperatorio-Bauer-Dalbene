using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public enum EnemyBehaviourStatus
{
    None, Idle, Chasing, Attacking, RangedAttacking, Damaged, Dead
}
public class EnemyZombie : BaseEnemy
{
    // References
    private EnemyZombieAnimationSounds _animSounds;
    private DatabaseCharacterZombie _zombieData;

    // Lite AI values
    [SerializeField] private Vector3 _attackRadiusOffset;    
    private EnemyBehaviourStatus _behaviour;
    private Transform _target;
    private int _layer_mask;

    private float _currentIdleTime;
    private float _extraIdleAnim = 30;
    private float _curretWalkingAnimVariation;
    private float _currentAttackTime;
    private int _currentAttackIndex;
    private Vector3 _movement;

    private bool IASwapIdleAnim => _currentIdleTime <= 0;
    private bool IACanAttackAgain => _currentAttackTime <= 0;
    private bool IAIsFacingEnemy => ((EnemyTarget.position - transform.position).normalized - transform.forward).magnitude <= ZombieData.ZedFacingEnemyMinTolerance;
    private bool IAIsOnAggroRange => (EnemyTarget.position - transform.position).magnitude <= ZombieData.ZedAggroRange;
    private bool IAIsOnAttackRange => (EnemyTarget.position - transform.position).magnitude <= ZombieData.ZedAttackRange;
    private Transform EnemyTarget => _target;
    private Vector3 EnemyDirection => (EnemyTarget.position - transform.position).normalized;

    // Public values
    public DatabaseCharacterZombie ZombieData => _zombieData;
    public EnemyBehaviourStatus ZombieBehaviourStatus => _behaviour;


    protected private override void Start()
    {
        _layer_mask = LayerMask.GetMask("Player", "Default", "Floor");
        _animSounds = GetComponentInChildren<EnemyZombieAnimationSounds>();
        _zombieData = (DatabaseCharacterZombie)CharacterData;
        ZombieIdleRandomizeExtraAnim();
        base.Start();

        UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
        _animSounds.OnAttackAnimation += OnAnimAttack;
    }

    protected private override void Update()
    {
        if (PlayerEvents.PlayerDead)
        {
            _movement = Vector3.zero;
            UpdateMovement(CharacterMovementStatus.Idle);
            return;
        }
        if (IsDead) return;

        float delta = Time.deltaTime;

        UpdateStunTime(delta);
        ZombieBehaviour(delta);
        ZombieWalking(delta);
    }

    private void FixedUpdate()
    {
        CharacterGravitry();
        if (PlayerEvents.PlayerDead) return;
        _target = PlayerEvents.PlayerLocation;

        if (_movement != Vector3.zero) MoveCharacter(_movement);
    }

    public override void AdditionalCharacterSetup()
    {
        // Modifying the pitch makes the zeds a little more "unique"
        Audio.pitch = Audio.pitch + Random.Range(ZombieData.SoundZombieMinPitch, ZombieData.SoundZombieMaxPitch);
    }

    public override void GetStun(float time)
    {
        Anim.SetInteger("damageVariation", (int)Random.Range(0, 2));
        base.GetStun(time);
    }

    public override void GetDamage(float amount, float stunChance)
    {
        Audio.PlayOneShot(SoundsManager.SoundsDatabase.SoundBulletHit, 2);
        base.GetDamage(amount, stunChance);
    }

    // Lite IA managment
    protected private virtual void UpdateBehaviourStatus(EnemyBehaviourStatus newStatus)
    {
        _behaviour = newStatus;
    }

    protected private virtual void ZombieBehaviour(float delta)
    {
        _movement = Vector3.zero;
        if (IsStunned) return;
        if (ZombieBehaviourStatus != EnemyBehaviourStatus.Idle) Anim.SetBool("isIdling", false);

        if (!IACanAttackAgain)
        {
            _currentAttackTime -= delta;
            return;
        }
        

        switch (ZombieBehaviourStatus)
        {
            case EnemyBehaviourStatus.None: break;
            case EnemyBehaviourStatus.Idle:
                // Swap between chasing & idle by checking aggro distance
                if (EnemyTarget != null)
                {
                    RaycastHit idlehit = CheckLoS();

                    if (IAIsOnAggroRange && idlehit.collider != null && idlehit.collider.CompareTag("Player"))
                    {
                        UpdateBehaviourStatus(EnemyBehaviourStatus.Chasing);
                        break;
                    }
                }

                Anim.SetBool("isIdling", true);
                ZombieIdle(delta);
                UpdateMovement(CharacterMovementStatus.Idle);
                UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
                break;

            case EnemyBehaviourStatus.Chasing:
                RaycastHit chasehit = CheckLoS();
                if (chasehit.collider == null || !chasehit.collider.CompareTag("Player"))
                {
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
                    break;
                }

                // Rotate towards player before starting to move
                if (!IAIsFacingEnemy)
                {
                    UpdateMovement(CharacterMovementStatus.Idle);
                    RotateCharacter(EnemyDirection, delta);
                    return;
                }

                // Generate player direction and move towards it
                UpdateMovement(CharacterMovementStatus.Walking);
                _movement = EnemyDirection;
                RotateCharacter(EnemyDirection, delta);

                // Check if enemy is in attack range and if the facing direction is close enough
                if (IAIsOnAttackRange && IAIsFacingEnemy)
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Attacking);
                break;

            case EnemyBehaviourStatus.Attacking:
                // Check if enemy goes out of range and start chasing it
                if (!IAIsOnAggroRange)
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Chasing);

                // Exec attack if on range
                UpdateMovement(CharacterMovementStatus.Idle);
                ZombieAttack();
                break;

            case EnemyBehaviourStatus.Damaged:
                break;

            case EnemyBehaviourStatus.Dead:
                break;
        }
    }

    protected private virtual void ZombieIdle(float delta)
    {
        if (ZombieBehaviourStatus != EnemyBehaviourStatus.Idle) return;

        if (_extraIdleAnim > 0) _extraIdleAnim -= delta;
        else
        {
            Audio.Stop(); Audio.PlayOneShot(ZombieData.SoundZombieErrands);
            Anim.SetTrigger("idleExtraVariation");
            ZombieIdleRandomizeExtraAnim();
        }

        if (IASwapIdleAnim)
        {
            Audio.PlayOneShot(ZombieData.SoundZombieErrands);
            Anim.SetInteger("idleVariation", Random.Range(1, 3));
            _currentIdleTime = Random.Range(10, 30);
        }

        else
            _currentIdleTime -= delta;
    }

    private void ZombieIdleRandomizeExtraAnim()
    {
        _extraIdleAnim = Random.Range(20, 120f);
    }

    protected private virtual void ZombieWalking(float delta)
    {
        // If speed is higher than this, then the slower animation is not used
        if (ZombieData.CharacterSpeed > 1.25f)
        {
            Anim.SetInteger("walkingVariation", 2);
            return;
        }

        // Swap random idle animations
        if (MovementStatus == CharacterMovementStatus.Idle)
        {
            if (_curretWalkingAnimVariation > 0) _curretWalkingAnimVariation -= delta;
            else
            {
                Anim.SetInteger("walkingVariation", Random.Range(0, 2));
                _curretWalkingAnimVariation = Random.Range(5, 20);
            }
        }
    }

    protected private virtual void ZombieAttack()
    {
        _currentAttackIndex = Random.Range(1, 5);
        _currentAttackTime = ZombieData.ZedAttackOutTime[_currentAttackIndex - 1];
        Anim.SetInteger("attackVariation", _currentAttackIndex);
        Anim.SetTrigger("isAttacking");

        // Reset status
        UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
    }

    protected private virtual void OnAnimAttack()
    {
        Collider[] hitColliders = new Collider[25];
        Physics.OverlapSphereNonAlloc(transform.position + transform.forward + _attackRadiusOffset, ZombieData.ZedAttackRange / 1.5f, hitColliders);

        foreach (Collider collider in hitColliders)
        {
            if (collider == null) continue;
            if (!collider.CompareTag("Player")) continue;

            collider.gameObject.TryGetComponent(out IDamageable damageable);            
            damageable?.GetDamage(ZombieData.ZedAttackDamage[_currentAttackIndex - 1], ZombieData.ZedAttackStunChance[_currentAttackIndex - 1]);
        }
        
    }

    protected private virtual RaycastHit CheckLoS()
    {
        Physics.Raycast(transform.position + new Vector3(0, 1, 0), EnemyDirection, out RaycastHit rHit, ZombieData.ZedAggroRange, _layer_mask);
        return rHit;
    }
}
