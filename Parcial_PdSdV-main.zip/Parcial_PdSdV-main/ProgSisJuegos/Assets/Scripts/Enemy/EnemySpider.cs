using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpider : BaseEnemy
{
    // References
    [SerializeField] private Transform _spitSpawnPosition;
    private BaseProjectile _lastProjectile;
    private EnemySpiderAnimationEvents _animEvents;
    private DatabaseCharacterSpider _spiderData;

    // Lite IA values
    private EnemyBehaviourStatus _behaviour;
    private Transform _target;
    private int _layer_mask;
    private bool _forceRotation;
    private float _currentAttackOutTime;
    private Vector3 _movement;

    private bool IACanMove => _currentAttackOutTime <= 0;
    private bool IACanAttackAgain => _currentAttackOutTime <= 0;
    private bool IAIsFacingEnemy => ((EnemyTarget.position - transform.position).normalized - transform.forward).magnitude <= SpiderData.SpiderFacingTolerance;
    private bool OnAggroRange => EnemyDistance <= SpiderData.SpiderAggroRange;
    private bool OnAttackRange => EnemyDistance <= SpiderData.SpiderAttackRange;
    private Vector3 EnemyDirection => (EnemyTarget.position - transform.position).normalized;
    private float EnemyDistance => Vector3.Distance(transform.position, EnemyTarget.position);

    // Public values
    public DatabaseCharacterSpider SpiderData => _spiderData;
    public EnemyBehaviourStatus SpiderBehaviourStatus => _behaviour;
    public Transform EnemyTarget => _target;

    protected private override void Start()
    {
        _layer_mask = LayerMask.GetMask("Player", "Default", "Floor");
        _animEvents = GetComponentInChildren<EnemySpiderAnimationEvents>();
        _spiderData = (DatabaseCharacterSpider)CharacterData;

        _animEvents.OnSpitAttack += SpiderExecSpitAttack;

        base.Start();
        UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
    }

    protected private override void Update()
    {
        if (PlayerEvents.PlayerDead)
        {
            _movement = Vector3.zero;
            UpdateMovement(CharacterMovementStatus.Idle);
            return;
        }

        if (IsDead)
        {
            this.enabled = false;
            return;
        }

        float delta = Time.deltaTime;
        _target = PlayerEvents.PlayerLocation;

        IAUpdateTimers(delta);
        SpiderBehaviour(delta);

        if (_forceRotation)
            RotateCharacter(EnemyDirection, delta);
    }

    protected private void FixedUpdate()
    {
        CharacterGravitry();
        if (_movement != Vector3.zero && IACanMove) MoveCharacter(_movement);
    }

    public override void AdditionalCharacterSetup()
    {
        Audio.pitch = Audio.pitch + Random.Range(SpiderData.SoundSpiderMinPitch, SpiderData.SoundSpiderMaxPitch);
    }

    // Lite IA managment
    protected private virtual void UpdateBehaviourStatus(EnemyBehaviourStatus newStatus)
    {
        _behaviour = newStatus;
    }

    protected private virtual void SpiderBehaviour(float delta)
    {
        _movement = Vector3.zero;
        if (EnemyTarget == null) return;

        // Wait for out times (animations) to end before executing anything else
        if (!IACanMove)
            return;

        switch (SpiderBehaviourStatus)
        {
            case EnemyBehaviourStatus.Idle:
                RaycastHit idlehit = CheckLoS();
                if (OnAggroRange && idlehit.collider != null && idlehit.collider.CompareTag("Player"))
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Chasing);

                else
                {
                    if (!Audio.isPlaying && Random.value > 0.99f) Audio.PlayOneShot(SpiderData.SoundSpiderErrands);
                    UpdateMovement(CharacterMovementStatus.Idle);
                }
                break;

            case EnemyBehaviourStatus.Chasing:
                RaycastHit chasehit = CheckLoS();
                if (!OnAggroRange || chasehit.collider == null || !chasehit.collider.CompareTag("Player"))
                {
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
                    Anim.SetBool("isWalking", false);
                    break;
                }
                if (!Audio.isPlaying && Random.value > 0.99f) Audio.PlayOneShot(SpiderData.SoundSpiderErrands);

                else
                {
                    if (IACanMove)
                    {
                        UpdateMovement(CharacterMovementStatus.Walking);
                        _movement = EnemyDirection;
                        RotateCharacter(EnemyDirection, delta);
                    }

                    if (IAIsFacingEnemy)
                    {
                        if (OnAttackRange && IACanAttackAgain)
                            UpdateBehaviourStatus(EnemyBehaviourStatus.RangedAttacking); 
                    }

                }
                break;

            case EnemyBehaviourStatus.RangedAttacking: 
                SpiderSpitAttack();
                UpdateMovement(CharacterMovementStatus.Idle);

                if (!OnAttackRange)
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Chasing);
                break;

            case EnemyBehaviourStatus.Damaged:
                break;

            case EnemyBehaviourStatus.Dead: UpdateBehaviourStatus(EnemyBehaviourStatus.None); break;
        }
    }

    protected private virtual void IAUpdateTimers(float delta)
    {
        if (!IACanAttackAgain) _currentAttackOutTime -= delta;
    }

    protected private virtual RaycastHit CheckLoS()
    {
        Physics.Raycast(transform.position + new Vector3(0, 1, 0), EnemyDirection, out RaycastHit rHit, SpiderData.SpiderAggroRange, _layer_mask);
        return rHit;
    }


    protected private virtual void SpiderSpitAttack()
    {
        Audio.Stop();
        Audio.PlayOneShot(SpiderData.SoundSpiderAttack);

        _forceRotation = true;
        _currentAttackOutTime = SpiderData.SpiderAttackOutTime;

        Anim.SetTrigger("isAttacking");
    }

    // Animation triggers spit projectile spawn
    protected private virtual void SpiderExecSpitAttack()
    {
        _forceRotation = false;
        BaseProjectile projectile = Instantiate(GetLatestProjectileInfoClone(), _spitSpawnPosition.transform.position, new Quaternion());
        projectile.direction = transform.forward;
    }

    private BaseProjectile GetLatestProjectileInfoClone()
    {
        var newProjectile = Cloner.CloneObject(SpiderData.SpiderSpiteProjectile);

        if (newProjectile is BaseProjectile castedProjectile)
            return castedProjectile;

        return null;
    }
}
