using System;

public class EnemySpiderAnimationEvents : BaseCharacterAnimationsSounds
{
    public Action OnSpitAttack;

    public override void PlayFootstepClip()
    {
        // some switch to play appropiate footstep sound
        Audio.PlayOneShot(SoundsManager.SoundsDatabase.SoundSpiderFootStep);
    }

    public void ActionSpitAttack()
    {
        OnSpitAttack();
    }
}
