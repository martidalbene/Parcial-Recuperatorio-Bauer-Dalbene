using System;

public class EnemyZombieAnimationSounds : BaseCharacterAnimationsSounds
{
    public Action OnAttackAnimation;

    public virtual void PlaySwingClip()
    {
        OnAttackAnimation?.Invoke();
        Audio.PlayOneShot(SoundsManager.SoundsDatabase.SoundSwing);
    }
}
