using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyT00 : BaseEnemy
{
    // References
    [SerializeField] private Transform _rockSpawnPosition;
    private BaseProjectile _currentRock;
    private BaseProjectile _lastProjectile;
    private EnemyT00AnimationEvents _animEvents;
    private DatabaseCharacterT00 _tyrantData;

    // Lite IA values
    [SerializeField] private Vector3 _attackRadiusOffset = new Vector3(0.15f, 1.2f);
    private EnemyBehaviourStatus _behaviour;
    private Transform _target;
    private int _layer_mask;
    private Vector3 _movement;

    private float _currentMeleeOutTime;
    private float _currentRockOutTime;
    private bool _randomRockAttack;
    private float _randomRockAttackTime;
    private float _currentRockAttackTime;
    private bool _forceRotation;

    private bool IACanMove => _currentRockOutTime <= 0 && IACanMeleeAttackAgain;
    private bool IACanMeleeAttackAgain => _currentMeleeOutTime <= 0;
    private bool IACanRockAttackAgain => _randomRockAttack;
    private bool IAIsFacingEnemy => ((EnemyTarget.position - transform.position).normalized - transform.forward).magnitude <= _tyrantData.TyrantFacingTolerance;

    private bool OnAggroRange => (EnemyTarget.position - transform.position).magnitude <= TyrantData.TyrantAggroRange;
    private bool OnMeleeRange => (EnemyTarget.position - transform.position).magnitude <= TyrantData.TyrantMeleeAttackRange;
    private bool OnRockRange => (EnemyTarget.position - transform.position).magnitude <= TyrantData.TyrantRockAttackRange && (EnemyTarget.position - transform.position).magnitude >= TyrantData.TyrantRockAttackRange / 3;

    private Vector3 EnemyDirection => (EnemyTarget.position - transform.position).normalized;
    private float EnemyDistance => Vector3.Distance(transform.position, EnemyTarget.position);

    // Public values
    public DatabaseCharacterT00 TyrantData => _tyrantData;
    public EnemyBehaviourStatus TyrantBehaviourStatus => _behaviour;
    public Transform EnemyTarget => _target;

    protected private override void Start()
    {
        _layer_mask = LayerMask.GetMask("Player", "Default", "Floor");
        _animEvents = GetComponentInChildren<EnemyT00AnimationEvents>();
        _tyrantData = (DatabaseCharacterT00)CharacterData;

        _animEvents.OnMeleeAttack += TyrantExecMeleeAttack;
        _animEvents.OnRockAttack += TyrantExecRockAttack;

        base.Start();
        UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
    }

    protected private override void Update()
    {
        if (PlayerEvents.PlayerDead)
        {
            UpdateMovement(CharacterMovementStatus.Idle);
            return;
        }
        if (IsDead)
        {
            this.enabled = false;
            return;
        }

        float delta = Time.deltaTime;
        _target = PlayerEvents.PlayerLocation;

        IAUpdateTimers(delta);
        TyrantBehaviour(delta);

        if (_forceRotation)
            RotateCharacter(EnemyDirection, delta);
    }

    protected private void FixedUpdate()
    {
        CharacterGravitry();
        if (_movement != Vector3.zero && IACanMove && !PlayerEvents.PlayerDead) MoveCharacter(_movement);
    }

    public override void AdditionalCharacterSetup()
    {
        Audio.pitch = Audio.pitch + Random.Range(TyrantData.SoundTyrantMinPitch, TyrantData.SoundTyrantMaxPitch);
    }

    public override void GetDamage(float amount, float stunChance)
    {
        Audio.PlayOneShot(SoundsManager.SoundsDatabase.SoundBulletHit, 2);
        base.GetDamage(amount, 0);

        if (Random.value > 0.5f) Audio.PlayOneShot(TyrantData.SoundDamaged, 1);
    }

    public override void GetDeath()
    {
        _animEvents.OnMeleeAttack -= TyrantExecMeleeAttack;
        _animEvents.OnRockAttack -= TyrantExecRockAttack;
        if (_currentRock != null) Destroy(_currentRock.gameObject);

        base.GetDeath();
    }

    // Lite IA managment
    protected private virtual void UpdateBehaviourStatus(EnemyBehaviourStatus newStatus)
    {
        _behaviour = newStatus;
    }

    protected private virtual void TyrantBehaviour(float delta)
    {
        _movement = Vector3.zero;
        if (EnemyTarget == null) return;

        // Wait for out times (animations) to end before executing anything else
        if (!IACanMove)
        {
            UpdateMovement(CharacterMovementStatus.Idle);
            return;
        }

        switch (TyrantBehaviourStatus)
        {
            case EnemyBehaviourStatus.Idle:
                RaycastHit idlehit = CheckLoS();

                if (OnAggroRange && idlehit.collider != null && idlehit.collider.CompareTag("Player"))
                {
                    Anim.SetBool("isIdling", false);
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Chasing);
                }
                else
                {
                    if (!Audio.isPlaying && Random.value > 0.99f) Audio.PlayOneShot(TyrantData.SoundTyrantErrands);
                    UpdateMovement(CharacterMovementStatus.Idle);
                }
                break;

            case EnemyBehaviourStatus.Chasing:
                RaycastHit chasehit = CheckLoS();
                if (!OnAggroRange || chasehit.collider == null || !chasehit.collider.CompareTag("Player"))
                {
                    UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);
                    break;
                }

                if (!Audio.isPlaying && Random.value > 0.99f) Audio.PlayOneShot(TyrantData.SoundTyrantErrands);

                else
                {
                    if (IACanMove)
                    {
                        if (EnemyDistance <= TyrantData.TyrantAggroRange / 5) UpdateMovement(CharacterMovementStatus.Running);
                        else UpdateMovement(CharacterMovementStatus.Walking);
                        _movement = EnemyDirection;
                        RotateCharacter(EnemyDirection, delta);
                    }

                    if (IAIsFacingEnemy)
                    {
                        if (OnMeleeRange && IACanMeleeAttackAgain) UpdateBehaviourStatus(EnemyBehaviourStatus.Attacking);
                        if (OnRockRange && IACanRockAttackAgain) UpdateBehaviourStatus(EnemyBehaviourStatus.RangedAttacking);
                    }
                    
                }
                break;

            case EnemyBehaviourStatus.Attacking: TyrantMeleeAttack(); break;
            case EnemyBehaviourStatus.RangedAttacking: TyrantRockAttack(); break;
            case EnemyBehaviourStatus.Dead: UpdateBehaviourStatus(EnemyBehaviourStatus.None); break;
        }

    }

    protected private virtual RaycastHit CheckLoS()
    {
        Physics.Raycast(transform.position + new Vector3(0, 1, 0), EnemyDirection, out RaycastHit rHit, TyrantData.TyrantAggroRange, _layer_mask);
        return rHit;
    }

    protected private virtual void IAUpdateTimers(float delta)
    {
        if (!IACanMeleeAttackAgain) _currentMeleeOutTime -= delta;

        // Wait for animation
        if (_currentRockAttackTime >  0) _currentRockAttackTime -= delta;
        if (_currentRockOutTime > 0) _currentRockOutTime -= delta;

        // Random chance to rock attack
        if (_randomRockAttackTime > 0)
            _randomRockAttackTime -= delta;
        else
        {
            _randomRockAttackTime = Random.Range(TyrantData.TyrantRockAttackMinTimeChance, TyrantData.TyrantRockAttackMaxTimeChance);
            _randomRockAttack = Random.value > 0.5f;
        }
    }

    // Trigger animation
    protected private virtual void TyrantMeleeAttack()
    {
        _currentMeleeOutTime = TyrantData.TyrantMeleeOutTime;
        _forceRotation = true;
        UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);

        Audio.Stop();
        Audio.PlayOneShot(TyrantData.SoundTyrantMeleeAttack);        
        Anim.SetTrigger("isAttacking");
    }

    protected private virtual void TyrantRockAttack()
    {
        Audio.Stop();
        Audio.PlayOneShot(TyrantData.SoundTyrantRockThrow);

        _forceRotation = true;
        _randomRockAttack = false;
        _currentRockOutTime = TyrantData.TyrantRockOutTime;
        Anim.SetTrigger("isRangeAttacking");

        
        // Spawn rock
        if (TyrantSpawnRock())
        {
            _currentRock = Instantiate(GetLatestProjectileInfoClone());
            _currentRock.transform.parent = _rockSpawnPosition;
            _currentRock.transform.localPosition = Vector3.zero;
            _currentRock.transform.localScale= Vector3.one;
        }

        // Reset status
        UpdateBehaviourStatus(EnemyBehaviourStatus.Idle);

        /*
        if (_lastProjectile == null)
        {
            Debug.Log("eeeeeeeeeeeeeeeeeeeeeeeeeeeeee nu�lo");
            var projectile = Instantiate(TyrantData.TyrantProjectile, _rockSpawnPosition);

            projectile.transform.parent = _rockSpawnPosition;
            projectile.transform.localPosition = Vector3.zero;

            projectile.TryGetComponent(out BaseProjectile result);

            if (result != null)
            {
                result.direction = EnemyDirection;
                result.damage = TyrantData.TyrantProjectile.damage;

                _lastProjectile = projectile.GetComponent<BaseProjectile>();
                _currentRock = _lastProjectile;
                return;
            }
        }

        else
        {
            _currentRock = Instantiate(GetLatestProjectileInfoClone());
            _currentRock.transform.parent = _rockSpawnPosition;
            _currentRock.transform.localPosition = Vector3.zero;
            Debug.Log("copying data");
        }
        */
    }

    // Animation triggers damaging zone
    protected private virtual void TyrantExecMeleeAttack()
    {
        _forceRotation = false;
        Collider[] hitColliders = new Collider[25];
        Physics.OverlapSphereNonAlloc(transform.position + transform.forward + _attackRadiusOffset, TyrantData.TyrantMeleeAttackRange / 1.5f, hitColliders);

        foreach (Collider collider in hitColliders)
        {
            if (collider == null) continue;
            if (!collider.CompareTag("Player")) continue;

            collider.gameObject.TryGetComponent(out IDamageable damageable);
            damageable?.GetDamage(TyrantData.TyrantMeleeDamange, TyrantData.TyrantMeleeStunChance);
        }
    }
    protected private virtual void TyrantExecRockAttack()
    {
        if (_currentRock != null)
        {
            _currentRock.TryGetComponent(out BaseProjectile projectile);
            _currentRock.TryGetComponent(out SphereCollider collider);
            _currentRock.TryGetComponent(out Rigidbody rbody);

            _rockSpawnPosition.DetachChildren();
            _currentRock.direction = EnemyDirection;

            collider.enabled = true;
            rbody.isKinematic = false;
            projectile.enabled = true;

            _currentRock = null;
        }

        _forceRotation = false;
    }
    
    // Animation rock attack
    protected private virtual BaseProjectile TyrantSpawnRock()
    {
        if (_lastProjectile != null) return _lastProjectile;

        _lastProjectile = TyrantData.TyrantProjectile;
        return _lastProjectile;
    }

    private BaseProjectile GetLatestProjectileInfoClone()
    {
        var newProjectile = Cloner.CloneObject(_lastProjectile);

        if (newProjectile is BaseProjectile castedProjectile)
            return castedProjectile;

        return null;
    }

}
