using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class EnemyPlaceholder : EnemyZombie
{
    public TextMeshPro visionStatus;
    private int _layer_mask_test;

    private protected override void Start()
    {
        base.Start();
        _layer_mask_test = LayerMask.GetMask("Player", "Default");
    }

    protected private override void Update()
    {
        UpdateMovement(CharacterMovementStatus.Idle);
        UpdateBehaviourStatus(EnemyBehaviourStatus.None);

        if (PlayerEvents.PlayerLocation != null)
        {
            RaycastHit idlehit = TestLoS();       
            bool status = idlehit.collider != null && idlehit.collider.CompareTag("Player");
            visionStatus.text = $"Do I see you? {status}";
        }
    }

    public override void GetDamage(float amount, float stunChance)
    {
        return;
    }

    public RaycastHit TestLoS()
    {
        Physics.Raycast(transform.position + new Vector3(0, 1, 0), (PlayerEvents.PlayerLocation.position - transform.position).normalized, out RaycastHit rHit, 20, _layer_mask_test);
        return rHit;
    }
}
