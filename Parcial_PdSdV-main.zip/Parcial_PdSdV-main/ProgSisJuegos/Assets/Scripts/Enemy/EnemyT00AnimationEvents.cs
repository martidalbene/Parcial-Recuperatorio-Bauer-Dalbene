using System;

public class EnemyT00AnimationEvents : EnemyZombieAnimationSounds
{
    public Action OnMeleeAttack;
    public Action OnRockAttack;

    public void ActionMeleeAttack()
    {
        OnMeleeAttack();
    }

    public void ActionRockAttack()
    {
        OnRockAttack();
    }
}
