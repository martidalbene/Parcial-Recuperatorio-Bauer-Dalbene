using System;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public enum UIStatus
{
    None, InGame, DeathMenu
}
public class UIManager : MonoBehaviour
{
    private UIStatus _status;

    [Header("Prefabs")]
    [SerializeField] private Image _inventoryItemPrefab;
    [SerializeField] private Image _inventoryItemSelectedPrefab;

    [Header("References")]
    [SerializeField] private Image _healthIndicator;
    [SerializeField] private Animator _healthAnimation;
    [SerializeField] private DeathMenu _deathScript;
    private AudioSource _uiAudioSource;

    [Header("Default weapon")]
    [SerializeField] private Image _defaltWeaponObject;

    [Header("Menu managment")]
    [SerializeField] private List<GameObject> _inGameHudObjects;
    [SerializeField] private List<GameObject> _deathMenuObjects;

    // Values
    private Image _inventoryItemSelectedObject;
    private HorizontalLayoutGroup _inventoryObject;
    private Dictionary<WeaponType, Image> _inventory = new Dictionary<WeaponType, Image>();
    private WeaponType _savedWeapType = WeaponType.None;

    private void Start()
    {
        UIEvents.OnInventoryAddWeapon += InventoryAddNewWeapon;
        UIEvents.OnInventoryUpdateCurrentWeapon += InventoryUpdateCurrentWeapon;
        UIEvents.PlayUISound += PlayUISound;
        PlayerEvents.OnHealthChange += PlayerHealthUpdate;
        PlayerEvents.OnPlayerDeath += PlayerDeath;
        PlayerEvents.OnPlayerEndLevel += PlayerEndLevel;
        PlayerEvents.UpdatePlayerDeath(false);

        _uiAudioSource = GetComponent<AudioSource>();
        _inventoryObject = GetComponentInChildren<HorizontalLayoutGroup>();

        // Pistol is the default weapon
        _inventory.Add(WeaponType.Pistol, _defaltWeaponObject);
        _inventoryItemSelectedObject = Instantiate(_inventoryItemSelectedPrefab);
        InventoryUpdateCurrentWeapon(WeaponType.Pistol);
    }

    private void OnDestroy()
    {
        UnsuscribeAllEvents();
    }

    private void UnsuscribeAllEvents()
    {
        UIEvents.OnInventoryAddWeapon -= InventoryAddNewWeapon;
        UIEvents.OnInventoryUpdateCurrentWeapon -= InventoryUpdateCurrentWeapon;
        UIEvents.PlayUISound -= PlayUISound;
        PlayerEvents.OnHealthChange -= PlayerHealthUpdate;
        PlayerEvents.OnHealthChange -= PlayerHealthUpdate;
        PlayerEvents.OnPlayerDeath -= PlayerDeath;
        PlayerEvents.OnPlayerEndLevel -= PlayerEndLevel;
    }

    private void UpdateUI()
    {
        switch (_status)
        {
            case UIStatus.None: break;
            case UIStatus.InGame: break;
            case UIStatus.DeathMenu:
                UnsuscribeAllEvents();
                foreach (GameObject item in _inGameHudObjects)
                    item.SetActive(false);

                foreach (GameObject item in _deathMenuObjects)
                    item.SetActive(true);
                break;
        }
    }

    private void InventoryAddNewWeapon(WeaponType type, Sprite icon)
    {
        if (_inventory.ContainsKey(type)) return;

        // Create new object and set icon
        Image item = Instantiate(_inventoryItemPrefab);
        item.sprite = icon;
        item.transform.SetParent(_inventoryObject.transform);

        // Reset scale
        item.transform.localScale = Vector3.one;

        _inventory.Add(type, item);

        // Refresh selected weapon
        InventoryUpdateCurrentWeapon(_savedWeapType);
    }

    private void InventoryUpdateCurrentWeapon(WeaponType weapon)
    {
        _inventory.TryGetValue(weapon, out Image item);
        if (item == null) return;

        // Manage selected indicator and fix scale
        _inventoryItemSelectedObject.transform.SetParent(item.transform, false);
        _inventoryItemSelectedObject.transform.position = item.transform.position;
        _inventoryItemSelectedObject.transform.localScale = item.transform.localScale * 3.5f;
    }

    private void PlayerHealthUpdate(float currentLife, bool isPoisoned)
    {
        if (!isPoisoned)
        {
            // Calculate health based on % and create "green to red" to paint the animation
            float health = (currentLife / 100) * 1;
            float loss = 1 - health;
            _healthIndicator.color = new Color(loss, health, 0);

            if (currentLife > 10) _healthAnimation.SetFloat("speed", 0.7f);
            if (currentLife > 20) _healthAnimation.SetFloat("speed", 0.65f);
            if (currentLife > 30) _healthAnimation.SetFloat("speed", 0.6f);
            if (currentLife > 40) _healthAnimation.SetFloat("speed", 0.55f);
            if (currentLife > 50) _healthAnimation.SetFloat("speed", 0.5f);
            if (currentLife > 60) _healthAnimation.SetFloat("speed", 0.45f);
            if (currentLife > 70) _healthAnimation.SetFloat("speed", 0.4f);
            if (currentLife > 80) _healthAnimation.SetFloat("speed", 0.35f);
            if (currentLife > 90) _healthAnimation.SetFloat("speed", 0.3f);
        }

        else
        {
            _healthIndicator.color = new Color(0.75f, 0, 1);
            _healthAnimation.SetFloat("speed", 0.2f);
        }
    }

    private void PlayUISound(AudioClip clip, float newVolume)
    {
        _uiAudioSource?.PlayOneShot(clip, newVolume);
    }

    private void PlayerDeath()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = true;

        _status = UIStatus.DeathMenu;
        UpdateUI();
    }

    private void PlayerEndLevel()
    {
        PlayerDeath();
        _deathScript.SwapText(true);
    }
}
