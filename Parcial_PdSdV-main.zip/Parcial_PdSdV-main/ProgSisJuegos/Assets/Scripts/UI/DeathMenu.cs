using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeathMenu : MonoBehaviour
{
    [SerializeField] private DatabaseScenes _scenes;
    [SerializeField] private List<GameObject> _disableObjectsOnClick = new List<GameObject>();
    [SerializeField] private TextMeshProUGUI _messageText;
    [SerializeField] private TextMeshProUGUI _playAgainText;

    private void Start()
    {
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.Confined;
    }

    private void Update()
    {
        Cursor.visible = true;
    }

    public void SwapText(bool isWin)
    {
        if (isWin)
        {
            _messageText.text = "GAME OVER";
            _playAgainText.text = "Play again";
        }
        else
        {
            _messageText.text = "YOU ARE DEAD";
            _playAgainText.text = "Try again";
        }
    }

    public void ButtonRestartLevel()
    {
        StartCoroutine(ChangeScene(_scenes.GameScene));
    }

    public void ExitToMainMenu()
    {
        StartCoroutine(ChangeScene(_scenes.MainMenu));
    }

    IEnumerator ChangeScene(string sceneName)
    {
        foreach (GameObject item in _disableObjectsOnClick)
            item.SetActive(false);

        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
        while (!asyncLoad.isDone) yield return null;
    }
}
