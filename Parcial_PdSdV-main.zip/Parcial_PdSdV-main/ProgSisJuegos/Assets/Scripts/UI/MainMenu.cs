using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    [SerializeField] private DatabaseScenes _scenes;

    [Header("Sections")]
    [SerializeField] private GameObject _mainMenuSection;
    [SerializeField] private GameObject _helpMenuSection;

    [Header("Health Animations")]
    [SerializeField] private Animator _healthCaut;
    [SerializeField] private Animator _healthWarn;
    [SerializeField] private Animator _healthPoison;

    [Header("Help Objects")]
    [SerializeField] private Image _helpKeysButton;
    [SerializeField] private Image _helpItemsButton;
    [SerializeField] private Image _helpHealthButton;

    [SerializeField] private GameObject _helpKeys;
    [SerializeField] private GameObject _helpItems;
    [SerializeField] private GameObject _helpHealth;

    private AudioSource _audio;

    private void Start()
    {
        _audio = GetComponent<AudioSource>();
        Cursor.lockState = CursorLockMode.Confined;
    }

    private void Update()
    {
        Cursor.visible = true;
    }

    public void ButtonStartGame()
    {
        _mainMenuSection.SetActive(false);
        _helpMenuSection.SetActive(false);

        StartCoroutine(StartGameDelay(_scenes.GameScene));
    }

    public void ButtonTestingScenario()
    {
        _mainMenuSection.SetActive(false);
        _helpMenuSection.SetActive(false);

        StartCoroutine(StartGameDelay(_scenes.TestScene));
    }

    public void ButtonHelp(bool goBack)
    {
        _mainMenuSection.SetActive(goBack);
        _helpMenuSection.SetActive(!goBack);
    }

    public void ExitGame()
    {
        Application.Quit();
    }

    IEnumerator StartGameDelay(string sceneName)
    {
        yield return new WaitForSeconds(3);
        StartCoroutine(ChangeScene(sceneName));
    }

    IEnumerator ChangeScene(string sceneName)
    {
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
        while (!asyncLoad.isDone) yield return null;
    }

    // Help buttons
    public void ButtonHelpKeys()
    {
        _helpKeys.SetActive(true);
        _helpItems.SetActive(false);
        _helpHealth.SetActive(false);

        _helpKeysButton.color = Color.gray;
        _helpItemsButton.color = Color.white;
        _helpHealthButton.color = Color.white;
    }

    public void ButtonHelpItems()
    {
        _helpKeys.SetActive(false);
        _helpItems.SetActive(true);
        _helpHealth.SetActive(false);

        _helpKeysButton.color = Color.white;
        _helpItemsButton.color = Color.gray;
        _helpHealthButton.color = Color.white;
    }

    public void ButtonHelpHealth()
    {
        _helpKeys.SetActive(false);
        _helpItems.SetActive(false);
        _helpHealth.SetActive(true);

        _healthCaut.SetFloat("speed", 0.35f);
        _healthWarn.SetFloat("speed", 0.6f);
        _healthPoison.SetFloat("speed", 0.2f);

        _helpKeysButton.color = Color.white;
        _helpItemsButton.color = Color.white;
        _helpHealthButton.color = Color.gray;
    }
}
