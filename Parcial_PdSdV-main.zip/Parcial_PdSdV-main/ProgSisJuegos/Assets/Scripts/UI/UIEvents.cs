using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIEvents : MonoBehaviour
{
    public static Action<WeaponType, Sprite> OnInventoryAddWeapon;
    public static Action<WeaponType> OnInventoryUpdateCurrentWeapon;
    public static Action<AudioClip, float> PlayUISound;
}
