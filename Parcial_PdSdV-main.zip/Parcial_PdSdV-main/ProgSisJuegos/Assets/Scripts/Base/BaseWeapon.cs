using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class BaseWeapon : MonoBehaviour, IWeapon
{
    [SerializeField] private DatabaseWeapon _weaponData;
    [SerializeField] private float _deployHolsterTime = 0.5f;
    [SerializeField] private Transform _muzzleTransform;
    private AudioSource _audio;

    private float _currentDeployHolsterTime = 1;
    private float _currentRecoil;

    public Action OnShoot;

    // Weapon stats
    public WeaponHandle Handle => _weaponData.Handler;
    public Sprite Icon => _weaponData.Icon;
    public AudioClip ShootAudio => _weaponData.ShootAudioClip;
    public float ShootAudioVolume => _weaponData.ShootAudioClipVolume;
    public float RecoilTime => _weaponData.Recoil;

    private void Start()
    {
        _audio = GetComponent<AudioSource>();
        _currentDeployHolsterTime = _deployHolsterTime;
    }

    public void OnDrawWeapon()
    {
        PlayAudio(DeploySound, DeploySoundVolume);
        _currentDeployHolsterTime = _deployHolsterTime;
    }

    public void OnHolsterWeapon()
    {
        PlayAudio(HolsterClip, HolsterSoundVolume);
        _currentDeployHolsterTime = _deployHolsterTime;
    }

    public void PlayAudio(AudioClip clip, float volume)
    {
        _audio?.PlayOneShot(clip, volume);
    }

    public virtual void Shoot(Vector3 outPos, Vector3 forward)
    {
        if (!Ready) return;
        
        OnShoot?.Invoke();        
        _currentRecoil = RecoilTime;

        PlayAudio(ShootAudio, ShootAudioVolume);
        Instantiate(_weaponData.MuzzlePartice, _muzzleTransform.position, _muzzleTransform.rotation);
        ShootBulletCast(outPos, forward);
    }

    public virtual void ShootBulletCast(Vector3 outPos, Vector3 forward)
    {
        if (Physics.Raycast(outPos, forward, out RaycastHit rHit, 50))
        {
            Vector3 hitPoint = rHit.point;
            Vector3 hitNormal = rHit.normal;

            if (rHit.transform.gameObject.layer == LayerMask.NameToLayer("Damageable"))
            {
                rHit.transform.TryGetComponent(out IDamageable damageable);
                damageable?.GetDamage(_weaponData.Damage, _weaponData.StunChance);

                // Body hit effects
                ParticleSystem effect = Instantiate(_weaponData.HitBodyPartice, hitPoint, new Quaternion());
                effect.transform.LookAt(PlayerEvents.PlayerLocation);
            }

            else if (rHit.transform != null)
            {
                ParticleSystem effect = Instantiate(_weaponData.HitWallPartice, hitPoint, new Quaternion());
                effect.transform.LookAt(PlayerEvents.PlayerLocation);
                GameManagerEvents.PlaySoundAtLocation(SoundsManager.SoundsDatabase.SoundBulletRicochet, rHit.point, 5);
            }
        }
    }

    public void Recoil(float delta)
    {
        if (_currentRecoil > 0) _currentRecoil -= delta;
        if (_currentDeployHolsterTime > 0) _currentDeployHolsterTime -= delta;
    }

    // IWeapon values
    public WeaponType Type => _weaponData.Type;
    public bool Ready => _currentDeployHolsterTime <= 0 && _currentRecoil <= 0;
    public AudioClip DeploySound => _weaponData.DeployAudioClip;
    public AudioClip HolsterClip => _weaponData.HolsterAudioClip;
    public float DeploySoundVolume => _weaponData.DeployAudioClipVolume;
    public float HolsterSoundVolume => _weaponData.HolsterAudioClipVolume;
}
