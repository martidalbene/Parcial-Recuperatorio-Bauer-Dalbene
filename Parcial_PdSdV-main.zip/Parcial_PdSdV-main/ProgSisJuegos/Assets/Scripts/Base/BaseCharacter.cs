using UnityEngine;


public enum CharacterMovementStatus {
    Idle, Walking, Running
}

public class BaseCharacter : MonoBehaviour, IDamageable
{
    // Configs
    [SerializeField] private DatabaseCharacter _characterData;

    [Header("Ground")]
    [SerializeField, Range(0, 2)] private float _groundDistance = 0.4f;
    [SerializeField, Range(1, 3)] private float _gravity = 1.5f;
    [SerializeField] private LayerMask _groundMask;
    [SerializeField] private Transform _groundCheck;
    private bool _isOnGround;
    private Vector3 _groundVel;

    // References
    private CharacterController _cController;
    private Animator _animator;
    private AudioSource _audio;

    // Values
    private float _currentLife = 1;
    private float _currentStunTime = 0;
    private CharacterMovementStatus _movementStatus;

    // Public values
    public DatabaseCharacter CharacterData => _characterData;
    public Animator Anim => _animator;
    public AudioSource Audio => _audio;
    public CharacterMovementStatus MovementStatus => _movementStatus;

    public float CurrentLife => _currentLife;
    public bool IsDead => _currentLife <= 0;
    public bool IsStunned => _currentStunTime > 0;

    protected private virtual void Start()
    {
        _cController = GetComponent<CharacterController>();
        _animator = GetComponentInChildren<Animator>();
        _audio = GetComponent<AudioSource>();

        _currentLife = CharacterData.CharacterLife;

        AdditionalCharacterSetup();
    }

    protected private virtual void Update()
    {
        UpdateStunTime(Time.deltaTime);
    }

    public virtual void CharacterGravitry()
    {
        // Fall to ground
        _isOnGround = Physics.CheckSphere(_groundCheck.position, _groundDistance, _groundMask);
        if (!_isOnGround)
            _groundVel.y = -1;

        MoveCharacter(_groundVel * _gravity);
    }

    public virtual void AdditionalCharacterSetup() { }

    protected virtual void MoveCharacter(Vector3 direction)
    {
        // Force animation change in case UpdateMovement is missing
        float speed = CharacterData.CharacterSpeed;
        Anim.SetBool("isWalking", true);
        Anim.SetBool("isRunning", false);

        if (_movementStatus == CharacterMovementStatus.Running)
        {
            Anim.SetBool("isWalking", false);
            Anim.SetBool("isRunning", true);
            speed += CharacterData.CharacterRunSpeed;
        }
        Vector3 directionFix = direction * 0.01f;

        _cController.Move(directionFix * speed);
    }

    protected virtual void MoveCharacter(Vector3 direction, float speed) 
    {
        _cController.Move(direction * speed);
    }

    protected virtual void RotateCharacter(Vector3 direction, float delta)
    {
        Vector3 noRotY = new Vector3(direction.x, 0, direction.z);
        transform.rotation = Quaternion.SlerpUnclamped(transform.rotation, Quaternion.LookRotation(noRotY), delta * CharacterData.CharacterTurnSpeed);
    }

    protected virtual void RotateCharacter(Vector3 direction)
    {
        transform.rotation = Quaternion.SlerpUnclamped(transform.rotation, Quaternion.LookRotation(direction), CharacterData.CharacterTurnSpeed);
    }

    protected virtual void Run()
    {
        UpdateMovement(CharacterMovementStatus.Running);
    }

    protected virtual void UpdateMovement(CharacterMovementStatus newStatus)
    {
        _movementStatus = newStatus;

        switch (_movementStatus)
        {
            case CharacterMovementStatus.Idle:
                Anim.SetBool("isIdling", true);
                Anim.SetBool("isWalking", false);
                Anim.SetBool("isRunning", false);
                break;

            case CharacterMovementStatus.Walking:
                Anim.SetBool("isIdling", false);
                Anim.SetBool("isWalking", true);
                Anim.SetBool("isRunning", false);
                break;

            case CharacterMovementStatus.Running:
                Anim.SetBool("isIdling", false);
                Anim.SetBool("isWalking", false);
                Anim.SetBool("isRunning", true);
                break;
        }
    }

    // Damageable events
    public virtual void GetDamage(float amount, float stunChance)
    {
        if (IsDead) return;

        _currentLife -= amount;

        if (_currentLife <= 0)
        {
            GetDeath();
            return;
        }

        float stun = Random.Range(0, 100);
        if (stun <= CharacterData.CharacterStunChance + stunChance) GetStun(CharacterData.CharacterStunTime);

        if (!Audio.isPlaying) Audio.PlayOneShot(CharacterData.SoundDamaged);
    }
    public virtual void GetHealth(float amount)
    {
        if (IsDead) return;
        _currentLife += amount;
        if (_currentLife > 100) _currentLife = 100;

    }
    public virtual void GetStun(float time)
    {
        UpdateMovement(CharacterMovementStatus.Idle);
        _currentStunTime = time;
        Anim.SetTrigger("getDamage");
    }
    public virtual void UpdateStunTime(float delta)
    {
        if (IsStunned) _currentStunTime -= delta;
    }
    public virtual void GetDeath()
    {
        Audio.Stop();
        Audio.PlayOneShot(CharacterData.SoundDeath);
        Anim.SetBool("isDead", true);
        _cController.enabled = false;
        this.enabled = false;
    }
}
