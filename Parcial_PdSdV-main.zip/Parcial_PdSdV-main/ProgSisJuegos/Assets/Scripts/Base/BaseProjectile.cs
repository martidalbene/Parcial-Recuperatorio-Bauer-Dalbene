using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseProjectile : MonoBehaviour, ICloneable
{
    [SerializeField, Range(0, 100)] private float _stunChance = 20;
    [SerializeField] private float _speed = 10;
    [SerializeField] private float _life = 5;

    private Rigidbody _rb;
    private AudioSource _audio;

    private bool _canMakeDamage = true;

    public float damage = 15;
    public Vector3 direction;

    public AudioSource Audio => _audio;
    public float StunChance => _stunChance;

    protected virtual private void Start()
    {
        _rb = GetComponent<Rigidbody>();
        _audio = GetComponent<AudioSource>();
        ProjectileInitialize();
    }

    protected virtual private void ProjectileInitialize()
    {
        transform.rotation = Quaternion.LookRotation(direction);
        _rb.AddForce(transform.forward * _speed, ForceMode.Impulse);
    }

    protected virtual private void OnCollisionEnter(Collision collision)
    {
        if (_rb.velocity.magnitude > 0.05) _rb.velocity = _rb.velocity / 1;
        if (!_canMakeDamage) return;
        _canMakeDamage = false;

        collision.transform.TryGetComponent(out IDamageable damageable);
        damageable?.GetDamage(damage, StunChance);
        if (damageable != null)
        {
            _rb.velocity = _rb.velocity / 5;
            Audio.PlayOneShot(SoundsManager.SoundsDatabase.SoundDebrisHit, 1);
        }

        this.gameObject.layer = LayerMask.NameToLayer("ProjectileIgnoreEveryone");
    }

    protected virtual private void Update()
    {
        _life -= Time.deltaTime;

        if (_life <= 0)
            Destroy(this.gameObject);
    }


    public ICloneable Clone()
    {
        var newProjectile = this;
        return newProjectile;
    }
}
