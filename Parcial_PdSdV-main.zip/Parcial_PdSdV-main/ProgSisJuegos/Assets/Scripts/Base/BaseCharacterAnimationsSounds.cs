using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseCharacterAnimationsSounds : MonoBehaviour
{
    private TerrainType _currentTerrainType = TerrainType.Gravel;

    private AudioSource _audio;
    public AudioSource Audio => _audio;

    private void Start()
    {
        _audio = GetComponent<AudioSource>();
    }

    public virtual void PlayFootstepClip()
    {
        Audio.PlayOneShot(SoundsManager.SoundsDatabase.SoundFootstep(_currentTerrainType));
    }

    public virtual void ChangeFootstepTerrainType(TerrainType terrainType)
    {
        _currentTerrainType = terrainType;
    }
}
