using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseItem : MonoBehaviour, IItem
{
    [SerializeField] private DatabaseItem _itemData;
    [SerializeField] private bool _destroyOnGrab = true;

    public ItemType Type => _itemData.Type;
    public AudioClip PickedUpSound => _itemData.PickedUpSound;
    public float PickedUpVolume => _itemData.PickedUpVolume;

    public DatabaseItemWeapon ItemData => (DatabaseItemWeapon)_itemData;
    public bool DestroyOnGrab => _destroyOnGrab;

    public virtual void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        OnItemGrab();
    }

    public virtual void OnItemGrab()
    {
        UIEvents.PlayUISound?.Invoke(_itemData.PickedUpSound, _itemData.PickedUpVolume);
        PlayerEvents.OnItemGrab?.Invoke(Type, WeaponType.None);
        if (DestroyOnGrab) Destroy(gameObject);
    }
}
