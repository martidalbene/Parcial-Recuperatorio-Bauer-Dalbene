using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundsManager : MonoBehaviour
{
    private static DatabaseSounds _sounds;
    public static DatabaseSounds SoundsDatabase => _sounds;
    
    public static void UpdateSoundsDatabase(DatabaseSounds newSounds)
    {
        _sounds = newSounds;
    }
}
