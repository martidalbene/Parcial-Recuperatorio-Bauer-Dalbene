using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

[RequireComponent(typeof(AudioSource))]
public class GameManager : MonoBehaviour
{
    [Header("Camera settings")]
    [SerializeField] private Camera _camera;
    [SerializeField] private Vector3 _cameraOffset;
    [SerializeField, Range(1, 10)] private float _cameraFollowSpeed = 3;
    [SerializeField] private bool _useCameraFollow = false;

    [Header("Databases")]
    [SerializeField] private List<DatabaseCharacterZombie> _enemyZombieList;
    [SerializeField] private List<DatabaseCharacterSpider> _enemySpiderList;
    [SerializeField] private List<DatabaseCharacterT00> _enemyTyrantList;

    [SerializeField] private List<DatabaseItem> _itemsList;
    [SerializeField] private DatabaseSounds _soundsLibrary;

    // Values
    private FactoryEnemy _factoryEnemy;
    private EventQueue _eventQueue;

    // References
    private AudioSource _audioSource;

    private void Awake()
    {
        _eventQueue = GetComponent<EventQueue>();
        _factoryEnemy = new FactoryEnemy(_enemyZombieList, _enemySpiderList, _enemyTyrantList);
    }

    private void Start()
    {
        UnityEngine.Cursor.visible = false;
        UnityEngine.Cursor.lockState = CursorLockMode.Locked;

        _audioSource = GetComponent<AudioSource>();
        SoundsManager.UpdateSoundsDatabase(_soundsLibrary);
        SubscribeToEvents();
    }

    void FixedUpdate()
    {
        if (_camera == null || PlayerEvents.PlayerLocation == null || !_useCameraFollow) return;

        _camera.transform.position = Vector3.LerpUnclamped(
            _camera.transform.position,
            PlayerEvents.PlayerLocation.position + _cameraOffset,
            Time.deltaTime * _cameraFollowSpeed);
    }

    private void OnDestroy()
    {
        UnsubscribeFromEvents();
    }

    private void SubscribeToEvents()
    {
        GameManagerEvents.EnqueueCommand += _eventQueue.EnqueueCommand;
        GameManagerEvents.PlaySoundAtLocation += PlaySoundAtLocation;
        GameManagerEvents.OnCameraChange += CameraChange;
        GameManagerEvents.CommandSpawnZombie += OnCommandSpawnZombie;
        GameManagerEvents.CommandSpawnSpider += OnCommandSpawnSpider;
    }

    private void UnsubscribeFromEvents()
    {
        GameManagerEvents.EnqueueCommand -= _eventQueue.EnqueueCommand;
        GameManagerEvents.PlaySoundAtLocation -= PlaySoundAtLocation;
        GameManagerEvents.OnCameraChange -= CameraChange;
        GameManagerEvents.CommandSpawnZombie -= OnCommandSpawnZombie;
        GameManagerEvents.CommandSpawnSpider -= OnCommandSpawnSpider;
    }

    private void OnCommandSpawnZombie(ZombieType type, Vector3 position, Quaternion rotation)
    {
        Instantiate(FactorySpawnEnemy(type.ToString()), position, rotation);
    }

    private void OnCommandSpawnSpider(SpiderType type, Vector3 position, Quaternion rotation)
    {
        Instantiate(FactorySpawnEnemy(type.ToString()), position, rotation);
    }

    private GameObject FactorySpawnEnemy(string code)
    {
        return _factoryEnemy.CreateProduct(code).gameObject;
    }

    private void PlaySoundAtLocation(AudioClip clip, Vector3 location, float volume)
    {
        GameObject gameObject = Instantiate(_soundsLibrary.SoundOneShotLocationPrefab);
        AudioSource audioSource = gameObject.GetComponent<AudioSource>();
        audioSource.clip = clip;
        audioSource.volume = volume;
        gameObject.transform.position = location;
        audioSource.Play();
    }

    private void CameraChange(Transform newTransform, KeyDirection newControlLayout, float newFov)
    {
        _camera.transform.position = newTransform.position;
        _camera.transform.rotation = newTransform.rotation;
        _camera.fieldOfView = newFov;

        PlayerEvents.OnPlayerSwitchControlScheme(newControlLayout);
    }
}
