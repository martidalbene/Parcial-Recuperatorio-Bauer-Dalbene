using System.Collections.Generic;
using UnityEngine;

public class FactoryEnemy : AbstractFactory<BaseEnemy>
{
    private Dictionary<string, EnemyZombie> _enemyZombies = new();
    private Dictionary<string, EnemySpider> _enemySpiders = new();
    private Dictionary<string, EnemyT00> _enemyTyrants = new();

    public FactoryEnemy(List<DatabaseCharacterZombie> zombieList, List<DatabaseCharacterSpider> spiderList, List<DatabaseCharacterT00> tyrantList)
    {
        foreach (DatabaseCharacterZombie enemyZed in zombieList)
            _enemyZombies.Add(enemyZed.ZedType.ToString(), (EnemyZombie)enemyZed.CharacterPrefab);

        foreach (DatabaseCharacterSpider enemySp in spiderList)
            _enemySpiders.Add(enemySp.SpiderType.ToString(), (EnemySpider)enemySp.CharacterPrefab);

        foreach (DatabaseCharacterT00 enemyTy in tyrantList)
            _enemyTyrants.Add(enemyTy.TyrantType.ToString(), (EnemyT00)enemyTy.CharacterPrefab);
    }

    public override BaseEnemy CreateProduct(string productCode)
    {
        if (_enemyZombies.TryGetValue(productCode, out EnemyZombie enemyZombie))
            return enemyZombie;

        if (_enemySpiders.TryGetValue(productCode, out EnemySpider enemySpider))
            return enemySpider;

        if (_enemyTyrants.TryGetValue(productCode, out EnemyT00 enemyTyrant))
            return enemyTyrant;

        return null;
    }
}
