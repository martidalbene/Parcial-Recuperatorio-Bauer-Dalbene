using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CommandSpawnZombie : ICommand
{
    private ZombieType _type;
    private Vector3 _position;
    private Quaternion _rotation;

    public CommandSpawnZombie(ZombieType type, Transform transform)
    {
        _type = type;
        _position = transform.position;
        _rotation = transform.rotation;
    }

    public void Execute()
    {
        GameManagerEvents.CommandSpawnZombie(_type, _position, _rotation);
    }
}
