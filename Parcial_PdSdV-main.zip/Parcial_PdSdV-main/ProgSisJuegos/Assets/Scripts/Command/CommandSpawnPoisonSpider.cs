using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CommandSpawnPoisonSpider : ICommand
{
    private EnemySpider _prefab;
    private Transform _transform;

    public CommandSpawnPoisonSpider(EnemySpider prefab, Transform transform)
    {
        _prefab = prefab;
        _transform = transform;
    }

    public void Execute()
    {
        Object.Instantiate(_prefab, _transform.position, _transform.rotation);
    }
}
