using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CommandSpawnTyrant : ICommand
{
    private EnemyT00 _prefab;
    private Transform _transform;

    public CommandSpawnTyrant(EnemyT00 prefab, Transform transform)
    {
        _prefab = prefab;
        _transform = transform;
    }

    public void Execute()
    {
        Object.Instantiate(_prefab, _transform.position, _transform.rotation);
    }
}
