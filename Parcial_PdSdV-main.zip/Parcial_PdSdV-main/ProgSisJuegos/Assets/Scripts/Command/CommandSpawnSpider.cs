using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class CommandSpawnSpider : ICommand
{
    private SpiderType _type;
    private Vector3 _position;
    private Quaternion _rotation;

    public CommandSpawnSpider(SpiderType type, Transform transform)
    {
        _type = type;
        _position = transform.position;
        _rotation = transform.rotation;
    }

    public void Execute()
    {
        GameManagerEvents.CommandSpawnSpider(_type, _position, _rotation);
    }
}
