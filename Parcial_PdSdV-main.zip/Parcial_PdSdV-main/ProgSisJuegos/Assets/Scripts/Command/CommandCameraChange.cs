using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CommandCameraChange : ICommand
{
    private Transform _transform;
    private KeyDirection _controlLayout;
    private float _fov;

    public CommandCameraChange(Transform transform, KeyDirection controlLayour, float fov)
    {
        _transform = transform;
        _controlLayout = controlLayour;
        _fov = fov;
    }

    public void Execute()
    {
        GameManagerEvents.OnCameraChange?.Invoke(_transform, _controlLayout, _fov);
    }
}
