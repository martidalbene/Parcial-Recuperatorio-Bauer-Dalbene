using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleTeleport : MonoBehaviour
{
    public Transform destination;
    public AudioClip triggerAudioClip;
    private AudioSource _audioSource;

    private void Start()
    {
        _audioSource= GetComponent<AudioSource>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        other.gameObject.SetActive(false);
        other.transform.position = destination.position;
        other.transform.rotation = destination.rotation;
        other.gameObject.SetActive(true);

        _audioSource.PlayOneShot(triggerAudioClip);
    }
}
