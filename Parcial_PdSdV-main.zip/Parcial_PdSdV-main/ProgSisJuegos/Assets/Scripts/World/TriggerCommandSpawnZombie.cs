using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerCommandSpawnZombie : MonoBehaviour
{
    [SerializeField] private ZombieType _type = ZombieType.Zombie01;
    private ICommand _command;

    private void Start()
    {
        _command = new CommandSpawnZombie(_type, transform);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        GameManagerEvents.EnqueueCommand(_command);

        Destroy(gameObject);
    }
}
