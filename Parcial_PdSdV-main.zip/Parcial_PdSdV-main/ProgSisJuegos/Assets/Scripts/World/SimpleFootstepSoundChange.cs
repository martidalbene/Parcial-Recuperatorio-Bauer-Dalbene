using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleFootstepSoundChange : MonoBehaviour
{
    public TerrainType type = TerrainType.Gravel;

    private void OnTriggerEnter(Collider other)
    {
        other.TryGetComponent(out BaseCharacter chScript);
        if (chScript != null)
        {
            BaseCharacterAnimationsSounds animSoundsScript = chScript.gameObject.GetComponentInChildren<BaseCharacterAnimationsSounds>();
            if (animSoundsScript != null) animSoundsScript.ChangeFootstepTerrainType(type);
        }        
    }
}
