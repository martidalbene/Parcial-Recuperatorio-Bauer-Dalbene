using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OneShotAudioSelfDestroy : MonoBehaviour
{
    private AudioSource _audio;

    private void Awake()
    {
        _audio = GetComponent<AudioSource>();
    }

    void FixedUpdate()
    {
        if (!_audio.isPlaying) Destroy(gameObject);
    }
}
