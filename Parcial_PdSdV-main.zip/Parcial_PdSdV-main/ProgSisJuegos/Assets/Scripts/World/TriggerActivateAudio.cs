using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerActivateAudio : MonoBehaviour
{
    public AudioSource audioSource;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        audioSource.Play();
    }

}
