using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerCommandSpawnSpider : MonoBehaviour
{
    [SerializeField] private SpiderType _type = SpiderType.Spider01;
    private ICommand _command;

    private void Start()
    {
        _command = new CommandSpawnSpider(_type, transform);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        GameManagerEvents.EnqueueCommand(_command);

        gameObject.SetActive(false);
    }
}
