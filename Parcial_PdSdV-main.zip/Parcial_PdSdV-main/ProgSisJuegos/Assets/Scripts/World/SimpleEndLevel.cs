using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleEndLevel : MonoBehaviour
{
    private EnemyT00 _endLevelTyrant;

    private void Awake()
    {
        _endLevelTyrant = GetComponent<EnemyT00>();
    }

    private void FixedUpdate()
    {
        if (_endLevelTyrant.IsDead)
        {
            PlayerEvents.OnPlayerEndLevel?.Invoke();
            this.enabled = false;
        }

    }
}
