using UnityEngine;

public class PatronesImplementados
{
    IInteractable strategy;
    DatabaseCharacter flyweight;
    IDamageable type_object;
    ICloneable prototype;
    FactoryEnemy abstract_factory;
    UIManager facade; /* en conjunto con UIEvents */ 
    ICommand command;
    GameManager observer;
    EventQueue event_queue;
}
